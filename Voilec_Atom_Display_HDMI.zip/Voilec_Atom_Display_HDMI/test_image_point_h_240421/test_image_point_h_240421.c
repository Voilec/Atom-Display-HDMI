//         Atom   utilities          //
//     Test of pictures in .C        //
//                                   //
//***********************************//
//        Christian Couderc          //
//         www.voilec.com            //
//***********************************//
//   240410

//  https://m5stack.lang-ship.com/howto/m5gfx/font/
//  https://m5stack.lang-ship.com/howto/m5gfx/basic/
//  d:\Arduino\Familles\______Atom\libraries\Adafruit_GFX_Library\
//  https://notisrac.github.io/FileToCArray

//#include <M5GFX.h>
//#include <M5AtomDisplay.h> // 68%
#include <C_Atom.h>
C_Atom tft;

//#include "jpg_image.h" // ->  1317 millisec
//#include "tableau_.h" // 16 bits   Little-endian   OK  -> 243 millisec
//#include "sun.h" // 
//#include "rolex.h"
//#include "rolex_500x300.h"
//#include "rolex_400x240.h"
//#include "rolex_261x200.h"  
//#include "rolex_196x150.h"  
//#include "rolex_624x478.h"  
//#include "ccd.h" 
//#include "enfants.h" //440x440
//#include "photo.h" 
//#include "B34.h" 
//#include "vend.h" 
//#include "rolex_706x540.h"
//#include "logo.h" // 
//#include "f800.h" // 
#include "tiger.h" 
const int16_t	w = 1280;
const int16_t	h = 720;
//M5AtomDisplay tft(w, h); //(1920, 1080 <- interdit ) , (1280, 720) , (960, 540) , (640, 360) ,(480, 270) , (320, 180)
int16_t	x00= w/2;
int16_t y00= h/2;
long top1, top2;
uint8_t delta=10;
// ***********************************

void setup() 
{
Serial.begin (115200);
delay(200);

tft.begin();

//tft.setColorDepth(24);
tft.setColorDepth(16);
tft.setCol  (TFT_YELLOW); 
//tft.setTxt (218,TFT_RED);
}

// ***********************************

void loop() 
{
 // tft.setColorDepth(24);
//tft.startWrite();tft.startWrite();
tft.fillScreen(TFT_BLACK);

//tft.drawJpg(rolex, ~0u, posX, posY, sizeX, sizeY, 0, 0, 0.0f, -1.0f); 

top1 = micros();
tft.drawJpg(rolex, ~0u, x00-rolexw/2, y00-rolexh/2, rolexw, rolexh, 0, 0, 0.0f, -1.0f); // 1316 milliSeconds
//tft.fillScreen(TFT_LIGHTGREY); // Duration = 15 µS ???
top2 = micros();

placeLogic (0, 0, rolexw, rolexh);
//placeGrid(x00-rolexw/2, y00-rolexh/2, rolexw, rolexh); 

tft.setCol (TFT_GOLD);
tft.setTxt (218,TFT_RED);
tft.startWrite();
tft.setCursor(100, h-50);
tft.print("Duration drawJpg()  : "); 
tft.print((int)(top2-top1));
tft.print("  microSeconds"); 

tft.endWrite();
while (1);
}

// ***********************************

void placeLogic (uint16_t posX, uint16_t posY, uint16_t rxw, uint16_t rxh)
{
//tft.drawLine(xClockCenter,  yClockCenter-51, xClockCenter,  yClockCenter+50);
//tft.drawLine(xClockCenter-50,  yClockCenter, xClockCenter+50,  yClockCenter);
tft.setCursor(posX,  posY+2*delta);
tft.setTxt (218, TFT_RED); // Font size, color	
tft.setCol (TFT_RED);
tft.print("   Wide: "); tft.print(rxw); tft.print("\n   Height: "); 
tft.print(rxh); 
}

// ***********************************

void placeGrid(uint16_t posX, uint16_t posY, uint16_t xW, uint16_t yH)
{
xW--;
yH--;  
tft.setCol (TFT_RED);   // Medianes
//tft.drawFastVLine (posX, posY, yH);
tft.drawFastVLine (posX+xW/2, posY, yH);
//tft.drawFastVLine (posX+xW, posY, yH);
tft.drawFastHLine (posX, posY+yH/2, xW);

tft.setColor (TFT_YELLOW); // Horizontales



tft.setCol (TFT_ORANGE);   // 2 Diagonales
tft.drawFastHLine (posX, posY+yH, xW);
tft.drawFastHLine (posX, posY,xW);

tft.setCol (TFT_WHITE);
tft.drawCircle(posX+xW/2, posY+yH/2, (yH/2)-3);
tft.drawCircle(posX+xW/2, posY+yH/2, (xW/2)-3);
tft.drawCircle(posX+xW/2, posY+yH/2, yH/4);
tft.drawCircle(posX+xW/2, posY+yH/2, yH/20);


tft.setColor (TFT_RED); // External frame
tft.drawFastVLine (posX, posY, xW);
tft.drawFastVLine (posX+xW, posY, yH);
tft.drawFastHLine (posX, posY, xW);
tft.drawFastHLine (posX, posY+yH, xW);

tft.setColor (TFT_NAVY); // Internal frame
tft.drawFastVLine (posX+delta, posY+delta, yH-2*delta);
tft.drawFastVLine (posX+xW-delta, posY+delta, yH-2*delta);
tft.drawFastHLine(posX+delta, posY+delta,xW-2*delta);
tft.drawFastHLine(posX+delta, posY+yH-delta, xW-2*delta);
} 
// ***********************************
