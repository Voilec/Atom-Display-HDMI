//***********************************//
//           Atom Display            //
//***********************************//
//        Christian Couderc          //
//         www.voilec.com            //
//***********************************//
//  240421

#include <C_Atom.h>

#define SERIAL_BAUD    115200


// ************************************

void C_Atom::init(int16_t _w, int16_t _h)
{
w=_w;
h=_h;	
M5AtomDisplay tft(w, h); //(1920, 1080 <- interdit ) , (1280, 720) , (960, 540) , (640, 360) ,(480, 270) , (320, 180)
}
// ************************************

void C_Atom::setCol(uint16_t _color)
{
color = _color;  
}
// *********************************

void C_Atom::setTxt(uint8_t _font, uint16_t _color)
{
switch (_font)
{	
case 2:
	setFont(&fonts::Font2);
	break;
case 9:
	setFont(&fonts::FreeSerif9pt7b);
	break; 
case 12:
	setFont(&fonts::FreeSerif12pt7b);
	break; 
case 18:
	setFont(&fonts::FreeSerif18pt7b); 
	break; 
case 24:
	setFont(&fonts::FreeSerif24pt7b); 
	break;
case 109:
	setFont(&fonts::FreeSans9pt7b);
	break;
case 112:
	setFont(&fonts::FreeSans12pt7b);
	break;
case 118:
	setFont(&fonts::FreeSans18pt7b); 
	break;
case 124:
	setFont(&fonts::FreeSans24pt7b); 
	break; 
case 206:
	setFont(&fonts::Font6);
	break;
case 207:
  setFont(&fonts::Font7); 
	break; 
case 208:
	setFont(&fonts::Font8);  
	break;
case 217:
	setFont(&fonts::Orbitron_Light_24); 
		break;
case 218:
default:
	setFont(&fonts::Orbitron_Light_32); 
	break;
}

font = _font;
color = _color;
setTextColor (_color);
}
// ************************************

void C_Atom::writeText(char* txt) 
{
print(txt);
}
// *********************************

void C_Atom::writeText(uint8_t nb) 
{
print(nb);
}
// *********************************

void C_Atom::writeText(int nb) 
{
print(nb);
}
// *********************************

void C_Atom::writeText(float nb) 
{
print(nb);
}
// *********************************

void C_Atom::fillTriang (int16_t x1, int16_t y1, int16_t x2, int16_t y2, int16_t	x3, int16_t y3, int16_t color, bool dbg) // Full 
{
fillTriangle (x1, y1, x2, y2,	x3, y3, color);
/*if (dbg==true)
	{
	setTxt (207, TFT_DARKGREEN); // Font color
	setTextColor(TFT_NAVY, TFT_PINK); // Font color + background
	setCursor (x1,y1-25);
	writeText("1");
	setCursor ( x2,y2-25);
	writeText("2");
	setCursor (x3,y3-25);
	writeText("3");
	}*/
}
// *********************************

// concave quadrilateral only : 1 -> 2 -> 3 -> 4 empty
void C_Atom::quadang (int16_t x1, int16_t y1, int16_t x2, int16_t y2, int16_t x3, int16_t y3, int16_t x4, int16_t y4, int16_t color) // Empty 
{
drawLine (x1, y1, x2, y2,color);
drawLine (x2, y2, x3, y3,color);
drawLine (x3, y3, x4, y4,color);
drawLine (x4, y4, x1, y1,color);
}	
// *********************************

// concave quadrilateral only : 1 -> 2 -> 3 -> 4  
void C_Atom::fillQuadang (int16_t x1, int16_t y1, int16_t x2, int16_t y2, int16_t x3, int16_t y3, int16_t x4, int16_t y4, int16_t color, bool dbg) // Fill 
{
fillTriangle (x1,y1, x2,y2, x3,y3, color);

if (dbg==true)
	{
	fillTriangle (x3,y3, x4,y4,	x1,y1, TFT_GOLD);	
	/*setTxt (207, TFT_DARKGREEN); // Font color
	setTextCol(TFT_NAVY, TFT_PINK); // Font color + background
	cursor (x1,y1-25);
	writeText("1");
	cursor ( x2,y2-25);
	writeText("2");
	cursor (x3,y3-25);
	writeText("3");
	cursor (x4,y4-25);
	writeText("4");		*/
	/* Droite point1, point2  y=ax+b
	a = (y2-y1/x2-x1)
	b = ((x2*y1)-(x1*y2)) / (x2-x1)
	pour x=0 -> Y=b
	pour x=w -> y= (w*(y2-y1/x2-x1)) + ((x2*y1)-(x1*y2)) / (x2-x1)
	*/
	

	uint16_t y00 = ((x2*y1)-(x1*y2)) / (x2-x1);
	uint16_t yhh = (w*(y2-y1)/(x2-x1)) + ((x2*y1)-(x1*y2)) / (x2-x1);
	fillCircle(w-10, yhh, 20, TFT_BROWN);	
	
	//drawLine(x1,y1, w,yhh, TFT_RED);
	//drawLine(x1,y1, yhh, 0, TFT_GREEN);
	drawLine(x2,y2, 0,y00, TFT_BLACK);
	setCursor (w-100, 100);
	setTxt(118, TFT_YELLOW);
	if (x1>x2)
		{
		drawLine(x1,y1, w,yhh, TFT_BROWN);
		drawLine(x2,y2, 0,y00, TFT_BLACK);
		writeText ("x1>x2");
		}
	else
		{
		drawLine(x1,y1, 0,yhh, TFT_GREEN);
		drawLine(x2,y2, w,y00, TFT_BROWN);
		writeText ("x1<x2");
		}			
	setCursor (w-100, 150);
	if (y1>y2)
		writeText ("y1>y2");
	else
		writeText ("y1<y2");	
	
	setCursor (50, h-100);
	writeText (y00);
	setCursor (w-100, h-100);
	writeText (yhh);
	fillCircle(w-10, yhh, 20, TFT_BROWN);
	}
else	
fillTriangle (x3,y3, x4,y4,	x1,y1, color);	
}
// *********************************

void C_Atom::swap (int16_t a, int16_t b)
{
int16_t w = a;
a=b;
b=w;
}	
// ***********************************

void C_Atom::placeXY (uint16_t xx, uint16_t yy , char* mark)
{
setCursor(xx-4, yy-9);
setTxt(109, TFT_YELLOW);
setTextColor(TFT_BLACK, TFT_PINK);
drawLine (xx-50, yy, xx+50, yy, TFT_BLACK);
drawLine (xx, yy-50, xx, yy+50, TFT_BLACK);
writeText (mark);
}

// **************************************************** 
