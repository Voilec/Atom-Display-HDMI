//***********************************//
//           Atom Display            //
//***********************************//
//        Christian Couderc          //
//         www.voilec.com            //
//***********************************//
#define atom_class   240421

//  https://m5stack.lang-ship.com/howto/m5gfx/font/
// https://m5stack.lang-ship.com/howto/m5gfx/basic/

#ifndef _CAtom_ 
#define _CAtom_

#include <Arduino.h>
#include <M5GFX.h>
#include <M5AtomDisplay.h> 
#include <M5Atom.h>

// ****************
#if defined debug_print
   #define debug_begin(x)      Serial.begin(x)
   #define debug(x)            Serial.print(x)
   #define debugln(x)          Serial.println(x)
#else
   #define debug_begin(x)
   #define debug(x)
   #define debugln(x)
#endif
// ****************

class C_Atom : public M5AtomDisplay
{
private:

protected:


public:
uint16_t color, textColor, textbgcolor;
uint16_t w, h; // Display resolution

uint8_t font;

void setCol(uint16_t _color);
void setTxt(uint8_t _font, uint16_t _color);
void writeText(char* txt); 
void writeText(uint8_t nb); 
void writeText(int nb);
void writeText(float nb); // ??????????
void init (int16_t w, int16_t h);
void fillTriang (int16_t x1, int16_t y1, int16_t x2, int16_t y2, int16_t x3, int16_t y3, int16_t color, bool dbg=false); // Fill 
void quadang (int16_t x1, int16_t y1, int16_t x2, int16_t y2, int16_t x3, int16_t y3, int16_t x4, int16_t y4, int16_t color); // Empty 
void fillQuadang (int16_t x1, int16_t y1, int16_t x2, int16_t y2, int16_t x3, int16_t y3, int16_t x4, int16_t y4, int16_t color, bool dbg=false); // Fill 
void swap (int16_t a, int16_t b);
void placeXY (uint16_t xx, uint16_t yy , char* mark);

/*  not yet implemented
void drawGradientLine(int32_t x0, int32_t y0, int32_t x1, int32_t y1, const T &colorstart, const T &colorend)
void fillCircleHelper(int32_t x, int32_t y, int32_t r, uint_fast8_t corners, int32_t delta, const T &color)
void fillEllipse(int32_t x, int32_t y, int32_t rx, int32_t ry, const T &color)
void drawArc(int32_t x, int32_t y, int32_t r0, int32_t r1, float angle0, float angle1, const T &color)
void fillArc(int32_t x, int32_t y, int32_t r0, int32_t r1, float angle0, float angle1, const T &color)
void drawBezier(int32_t x0, int32_t y0, int32_t x1, int32_t y1, int32_t x2, int32_t y2, const T &color)
void drawBezier(int32_t x0, int32_t y0, int32_t x1, int32_t y1, int32_t x2, int32_t y2, int32_t x3, int32_t y3, const T &color)
*/
} ;
// ****************
#endif