Read this explanatory page: https://www.voilec.com/pages/Atom_PSRAM.php

The Atom Display HDMI. Some programs to discover and test the capabilities of this product using the Arduino IDE 
The examples found in the libraries eventually work, but the displays are very slow!"

/////////////////////////////////////////////////
Christian Couderc   www.voilec.com
Copyright 2024
